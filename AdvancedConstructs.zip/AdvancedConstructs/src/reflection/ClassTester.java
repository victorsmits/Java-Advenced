package reflection;

/**
 *
 * @author Jean-Michel Busca
 */
public class ClassTester {

  public <T> void testClass(Class<T> clazz, String testName) {

  }

  public static void main(String[] args) {

  }
}
