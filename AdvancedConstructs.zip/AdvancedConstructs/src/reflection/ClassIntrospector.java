package reflection;

/**
 *
 * @author Jean-Michel Busca
 */
public class ClassIntrospector {

  public static <T> void printMethods(Class<T> clazz) {
  }

  public static void main(String[] args) {
  }

}
