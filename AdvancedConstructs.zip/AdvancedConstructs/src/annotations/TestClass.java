package annotations;

/**
 *
 * @author Jean-Michel Busca
 */
public class TestClass {

  public void foo() {
    System.out.println("foo");
  }

  public void bar() {
    System.out.println("bar");
  }

  public void baz() {
    System.out.println("baz");
  }

}
